#!/usr/bin/env python

from distutils.core import setup

setup(name='standard_format',
      version='0.01',
      description='Geomphon Standard CSV Format',
      author='Ewan Dunbar',
      author_email='ewan.dunbar@univ-paris-diderot.fr',
      packages=['standard_format']
     )
